import { type NextRequest, NextResponse } from "next/server"
import type { MiniAppSendTransactionSuccessPayload } from "@worldcoin/minikit-js"

interface IRequestPayload {
  payload: MiniAppSendTransactionSuccessPayload
}

export async function POST(req: NextRequest) {
  try {
    const { payload } = (await req.json()) as IRequestPayload

    const response = await fetch(
      `https://developer.worldcoin.org/api/v2/minikit/transaction/${payload.transaction_id}?app_id=${process.env.APP_ID}&type=transaction`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${process.env.DEV_PORTAL_API_KEY}`,
        },
      },
    )

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const transaction = await response.json()
    return NextResponse.json(transaction)
  } catch (error) {
    console.error("Error confirming payment:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to confirm payment",
      },
      {
        status: 500,
      },
    )
  }
}

