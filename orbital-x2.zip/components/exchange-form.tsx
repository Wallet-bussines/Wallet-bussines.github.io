'use client'

import { useState, useEffect } from 'react'
import { X, MoreVertical, AlertCircle } from 'lucide-react'
import Image from 'next/image'
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ExchangeFormData, PaymentMethod, ValidationError } from '@/types/exchange'
import { getTokenPrice, calculateReceiveAmount, isWhitelistedAddress, generateWhatsAppLink } from '@/lib/api'

export function ExchangeForm() {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState<ValidationError[]>([])
  const [tokenPrice, setTokenPrice] = useState(0)
  const [formData, setFormData] = useState<Partial<ExchangeFormData>>({
    amount: undefined,
    paymentMethod: 'Nequi'
  })

  useEffect(() => {
    const updatePrice = async () => {
      const price = await getTokenPrice('WLD')
      setTokenPrice(price)
    }
    
    updatePrice()
    const interval = setInterval(updatePrice, 30000) // Update every 30 seconds
    
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (formData.amount && tokenPrice) {
      const receiveAmount = calculateReceiveAmount(formData.amount, tokenPrice)
      setFormData(prev => ({
        ...prev,
        receiveAmount
      }))
    }
  }, [formData.amount, tokenPrice])

  const validateForm = (): ValidationError[] => {
    const errors: ValidationError[] = []
    
    if (!formData.amount || formData.amount <= 0) {
      errors.push({ field: 'amount', message: 'Ingrese una cantidad válida' })
    }
    
    if (step === 2) {
      if (!formData.name) {
        errors.push({ field: 'name', message: 'Ingrese su nombre completo' })
      }
      if (!formData.phone) {
        errors.push({ field: 'phone', message: 'Ingrese su número de teléfono' })
      }
      if (!formData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        errors.push({ field: 'email', message: 'Ingrese un correo electrónico válido' })
      }
      if (!formData.account) {
        errors.push({ field: 'account', message: 'Ingrese su número de cuenta' })
      }
      if (!formData.city) {
        errors.push({ field: 'city', message: 'Ingrese su ciudad' })
      }
      if (!formData.walletAddress) {
        errors.push({ field: 'walletAddress', message: 'Ingrese una dirección de wallet' })
      } else if (!isWhitelistedAddress(formData.walletAddress)) {
        errors.push({ field: 'walletAddress', message: 'La dirección de wallet no está autorizada' })
      }
    }
    
    return errors
  }

  const handleContinue = () => {
    const errors = validateForm()
    setErrors(errors)
    
    if (errors.length === 0) {
      if (step === 1) {
        setStep(2)
      } else if (step === 2) {
        setStep(3)
      }
    }
  }

  const handleSubmit = () => {
    if (formData.amount && formData.receiveAmount) {
      const whatsappLink = generateWhatsAppLink(formData as ExchangeFormData)
      window.open(whatsappLink, '_blank')
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white px-4 py-3 flex items-center justify-between">
        <button className="p-2">
          <X className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <Image
            src="/placeholder.svg"
            alt="Orbital-X Logo"
            width={32}
            height={32}
            className="rounded-lg bg-orange-500"
          />
          <span className="font-bold text-lg">ORBITAL-X</span>
        </div>
        <button className="p-2">
          <MoreVertical className="w-6 h-6" />
        </button>
      </header>

      {/* Main Content */}
      <main className="p-4 max-w-md mx-auto">
        <Card className="bg-white p-6 rounded-3xl">
          {/* Progress Steps */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center">
              {[1, 2, 3].map((stepNumber) => (
                <>
                  <div 
                    className={`w-8 h-8 rounded-full ${
                      stepNumber <= step ? 'bg-navy-900 text-white' : 'bg-gray-200'
                    } flex items-center justify-center font-semibold`}
                  >
                    {stepNumber}
                  </div>
                  {stepNumber < 3 && (
                    <div className={`w-16 h-[2px] ${
                      stepNumber < step ? 'bg-navy-900' : 'bg-gray-200'
                    }`} />
                  )}
                </>
              ))}
            </div>
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold text-center mb-8">
            Intercambio WLD ⚡
          </h1>

          {/* Error Messages */}
          {errors.length > 0 && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {errors.map((error, index) => (
                  <div key={index}>{error.message}</div>
                ))}
              </AlertDescription>
            </Alert>
          )}

          {/* Exchange Form */}
          <div className="space-y-6">
            {step === 1 && (
              <>
                {/* Send Section */}
                <div>
                  <h2 className="text-sm font-semibold text-gray-500 mb-2">ENVÍAS</h2>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-gray-900 rounded-full" />
                      <span>WLD</span>
                    </div>
                    <Input
                      type="number"
                      value={formData.amount?.toString() || ''}
                      onChange={(e) => {
                        const value = e.target.value === '' ? '' : Number(e.target.value);
                        setFormData({
                          ...formData,
                          amount: value === '' ? undefined : value,
                        });
                      }}
                      className="w-24 text-right"
                    />
                  </div>
                  <p className="text-sm text-gray-500 mt-2">
                    Precio estimado por token: {(tokenPrice * 4366).toLocaleString('es-CO', { minimumFractionDigits: 2 })} COP
                  </p>
                </div>

                {/* Receive Section */}
                <div>
                  <h2 className="text-sm font-semibold text-gray-500 mb-2">RECIBES</h2>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-2">
                      <Image
                        src="/placeholder.svg"
                        alt="Colombia Flag"
                        width={32}
                        height={32}
                        className="rounded-full"
                      />
                      <span>COP</span>
                    </div>
                    <span className="font-semibold">
                      {formData.receiveAmount?.toLocaleString('es-CO', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>

                {/* Payment Method */}
                <div>
                  <h2 className="text-sm font-semibold mb-2">Método de consignación</h2>
                  <Select
                    value={formData.paymentMethod}
                    onValueChange={(value) => setFormData({
                      ...formData,
                      paymentMethod: value as PaymentMethod
                    })}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Seleccionar método" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Nequi">Nequi</SelectItem>
                      <SelectItem value="Daviplata">Daviplata</SelectItem>
                      <SelectItem value="Ahorro">Ahorro</SelectItem>
                      <SelectItem value="Trasfiya">Trasfiya</SelectItem>
                      <SelectItem value="nu">nu</SelectItem>
                      <SelectItem value="Cuenta bancaria">Bancos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold mb-2 block">
                    Nombre y Apellidos
                  </label>
                  <Input
                    value={formData.name || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      name: e.target.value
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">
                    Teléfono
                  </label>
                  <Input
                    type="tel"
                    value={formData.phone || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      phone: e.target.value
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">
                    Correo Electrónico
                  </label>
                  <Input
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      email: e.target.value
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">
                    Número de Cuenta
                  </label>
                  <Input
                    value={formData.account || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      account: e.target.value
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">
                    Ciudad
                  </label>
                  <Input
                    value={formData.city || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      city: e.target.value
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">
                    Dirección de Wallet
                  </label>
                  <Input
                    value={formData.walletAddress || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      walletAddress: e.target.value
                    })}
                    placeholder="0x..."
                  />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Resumen de la Venta</h3>
                <div className="space-y-2">
                  <p>Método de pago: <span className="font-medium">{formData.paymentMethod}</span></p>
                  <p>Nombre y Apellidos: <span className="font-medium">{formData.name}</span></p>
                  <p>Teléfono: <span className="font-medium">{formData.phone}</span></p>
                  <p>Correo Electrónico: <span className="font-medium">{formData.email}</span></p>
                  <p>Número de Cuenta: <span className="font-medium">{formData.account}</span></p>
                  <p>Ciudad: <span className="font-medium">{formData.city}</span></p>
                  <p>Cantidad de tokens: <span className="font-medium">{formData.amount?.toLocaleString('es-CO')} WLD</span></p>
                  <p>Valor a recibir: <span className="font-medium">{formData.receiveAmount?.toLocaleString('es-CO')} COP</span></p>
                  <p>Dirección de Wallet: <span className="font-medium">{formData.walletAddress}</span></p>
                </div>
                <div className="flex flex-col gap-4">
                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      className="border-blue-300 text-blue-600 hover:bg-blue-50 flex-1"
                      onClick={() => setStep(2)}
                    >
                      Atrás
                    </Button>
                    <Button
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      onClick={handleSubmit}
                    >
                      Enviar
                    </Button>
                  </div>
                  <Button
                    variant="link"
                    className="text-sm text-blue-600 hover:text-blue-800"
                    onClick={() => setStep(1)}
                  >
                    Editar valores
                  </Button>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            {step < 3 && (
              <div className="flex gap-4">
                {step > 1 && (
                  <Button
                    variant="outline"
                    className="border-blue-300 text-blue-600 hover:bg-blue-50 flex-1"
                    onClick={() => setStep((prev) => (prev - 1))}
                  >
                    Atrás
                  </Button>
                )}
                <Button
                  className={`bg-blue-600 hover:bg-blue-700 text-white py-6 rounded-lg ${step === 1 ? 'w-full' : 'flex-1'}`}
                  onClick={handleContinue}
                  disabled={loading}
                >
                  {loading ? 'Procesando...' : 'CONTINUAR'}
                </Button>
              </div>
            )}
          </div>
        </Card>
      </main>
    </div>
  )
}

