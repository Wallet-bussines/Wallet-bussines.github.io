const BINANCE_API_BASE = 'https://api.binance.com/api/v3'
const WHITELISTED_ADDRESS = ''
const SUPPORT_PHONE = '3248092374'
const EXCHANGE_RATE_COP_USD = 4366

export async function getTokenPrice(symbol: string): Promise<number> {
  try {
    const response = await fetch(`${BINANCE_API_BASE}/ticker/price?symbol=${symbol}USDT`)
    const data = await response.json()
    return parseFloat(data.price)
  } catch (error) {
    console.error('Error fetching token price:', error)
    return 0
  }
}

export function calculateReceiveAmount(amount: number, priceUSD: number): number {
  const priceCOP = priceUSD * EXCHANGE_RATE_COP_USD
  return amount * priceCOP * (1 - 0.16) // 16% fee
}

export function isWhitelistedAddress(address: string): boolean {
  return address.toLowerCase() === WHITELISTED_ADDRESS.toLowerCase()
}

interface ExchangeFormData {
  amount: number;
  receiveAmount: number;
  paymentMethod: string;
  name: string;
  phone: string;
  email: string;
  account: string;
  city: string;
  walletAddress: string;
}

export function generateWhatsAppLink(data: ExchangeFormData): string {
  const message = `
    Venta de token WLD:
    - Cantidad: ${data.amount?.toLocaleString('es-CO') || 'N/A'} WLD
    - Valor a recibir: ${data.receiveAmount?.toLocaleString('es-CO') || 'N/A'} COP
    - Método de pago: ${data.paymentMethod}
    - Nombre y Apellidos: ${data.name}
    - Teléfono: ${data.phone}
    - Correo: ${data.email}
    - Cuenta: ${data.account}
    - Ciudad: ${data.city}
    - Dirección de Wallet: ${data.walletAddress}
  `;

  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${SUPPORT_PHONE}?text=${encodedMessage}`;
}

