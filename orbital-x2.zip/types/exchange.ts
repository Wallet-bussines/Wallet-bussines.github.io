export type PaymentMethod = 'Nequi' | 'Daviplata' | 'Ahorro' | 'Trasfiya' | 'nu' | 'Cuenta bancaria'

export interface ExchangeFormData {
  amount?: number;
  receiveAmount?: number;
  paymentMethod: PaymentMethod;
  name: string;
  phone: string;
  email: string;
  account: string;
  city: string;
  walletAddress: string;
}

export interface ValidationError {
  field: keyof ExchangeFormData
  message: string
}

