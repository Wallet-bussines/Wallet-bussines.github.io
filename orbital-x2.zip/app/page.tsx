import { ExchangeForm } from '@/components/exchange-form'

export default function HomePage() {
  return <ExchangeForm />
}

